Terms and conditions:
--------------------------------------------------------------------------------------------------


All our resources can be used for both personal and commercial projects.
 
We are not liable for the misuse of the resources we provide you. They can be customized and modified to fit your requirements.
     
Redistribution, resells, lease, license, sub-license or offering our resources to third party is not allowed. This includes uploading our resources to another website and offering our resources as a separate attachment from any of your work.
 
All our resources can be used by you or by the clients you purchase it for.
 
Some images are taken from pixabay.com, which are commercial free. 


--------------------------------------------------------------------------------------------------

Contact:support@template.net